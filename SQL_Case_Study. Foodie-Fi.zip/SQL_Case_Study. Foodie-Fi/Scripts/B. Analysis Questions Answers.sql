use foodie_fi;

-- Data Analysis Questions
-- 1.How many customers has Foodie-Fi ever had?

-- use the DISTINCT function to find the number of Foodie Fi's unique customers

SELECT
COUNT(DISTINCT customer_id) AS num_customers
FROM subscriptions;

 -- Foodie-Fi has 1000 unique customers.


-- 2. What is the monthly distribution of trial plan start_date values for our dataset — use the start of the month as the GROUP BY value

/*
Steps:
* Extract the months from start_date column
* COUNT the total number of plan_ids for each month
* And filter for where plan_name is Trial
*/

SELECT 
MONTH(start_date) AS Months,
COUNT(customer_id) AS Num_Customers
FROM subscriptions
GROUP BY Months;

-- March has the highest number of trial plans, whereas February has the lowest number of trial plans. 

-- 3. What plan ‘start_date’ values occur after the year 2020 for our dataset? Show the breakdown by count of events for each ‘plan_name’.
 
 /*
Steps:
Question is asking for the number of plans for start dates occurring in 2021 and after grouped by plan names.

* Filter plans with start_dates occurring after 2020-12-31
* Group and order results by plan.
*/

SELECT p.plan_name, p.plan_id , 
COUNT(*) AS Count_Event
FROM subscriptions s
JOIN plans p 
ON p.plan_id = s.plan_id
WHERE s.start_date >= '2021-01-01'
GROUP BY p.plan_name, p.plan_id
ORDER BY p.plan_id;
 
 -- The number of customers who churned the plan after the year 2020 is the biggest one
 
--  4. What is the customer count and percentage of customers who have churned the rounded to 1 decimal place?

/*
Steps:
* Count the total number of customers
* Get the percentage of customers by diving total customers with distinct number of customers and round it to 1 decimal place.
* Filter for where the plan_id is 4 which is Trial
*/

SELECT 
COUNT(*) AS Customer_Churn, 
ROUND(COUNT(*) * 100/ (SELECT COUNT(DISTINCT customer_id)FROM subscriptions),1) AS Perc_Churn
FROM subscriptions
WHERE plan_id = 4;

-- 307 customers, or 30.7% of the total customers, have churned from Food-fi during the period of analysis.

--  5. How many the customers have churned straight after their initial free trial — what the percentage is this rounded to the nearest whole number?

/*
Steps:
* use lag function to create a new column called "previous_plan" which stores the plan_id of the previous
  subscription plan for each customer.	
* get the total number of rows in the previous_plan column
* get the perecentage of customers and round to the nearest whole number
* Using the cte_churn CTE, filter for rows with plan_id of 4 (churn_plan) and previous_plan of 0(trial plan)
*/

WITH cte_churn AS 
(
-- use lag function to look at the previous row in the plan_id column resulting in previous_plan column
SELECT *,
	   LAG(plan_id, 1) OVER(PARTITION BY customer_id ORDER BY plan_id) AS previous_plan
FROM subscriptions
)
SELECT COUNT(previous_plan) AS churn_count, 
	   ROUND(COUNT(*) * 100 / (SELECT COUNT(DISTINCT customer_id) FROM subscriptions), 0) AS percentage_churn
FROM cte_churn
WHERE plan_id = 4 and previous_plan = 0;

-- There are 92 customers who churned immediately after their initial trial which is at 9% entire customer base.

    
-- 6. What is the number and percentage of customer plans after their initial free trial? 

/*
Question is asking for number and percentage of customers who converted to becoming paid customer after the trial. 

Steps:
* Find out customer's next plan using LEAD() function
* Find percentage using multiply the number of transactions by 100 and divide it by the number of customer
* Filter for plan_id = 0 as every customer has to start from the trial plan at 0
*/

WITH cte_next_plan AS ( 
SELECT *, 
    LEAD (plan_id, 1) OVER(PARTITION BY customer_id ORDER BY plan_id ) AS Next_Plan
  FROM subscriptions)
SELECT 
    Next_Plan, COUNT(*) AS Num_Customer, ROUND(COUNT(*) * 100/(SELECT COUNT(DISTINCT customer_id)
    FROM subscriptions),1) 
       AS Perc_Next_Plan
FROM cte_next_plan
WHERE  Next_Plan IS NOT NULL AND plan_id = 0
GROUP BY  Next_Plan
ORDER BY  Next_Plan;

/*More than 80% of customers are on paid plans,a with small 3.7% on plan 3 (pro annual $199). Foodie-fi has to restrategize on 
their customer acquisition strategy for customers who would be willing to spend more.
*/

-- 7. What is the customer count and percentage breakdown of all 5 plan_name values at 2020–12–31?

/*
Steps:
* Use LEAD() function to retrieve the next plan start_date located in the next row based on the curent row
* Find the breakdown of customers with existing plans on or after 2020-12-31
*/

  WITH cte_next_date AS (
  SELECT *,
      LEAD(start_date , 1) OVER(PARTITION BY customer_id ORDER BY start_date) AS Next_Date
  FROM subscriptions
  WHERE start_date <= '2020-12-31'), 
Plans_Breakdown AS (
SELECT 
    plan_id, COUNT(DISTINCT customer_id) AS num_customer
FROM cte_next_date
WHERE (next_date IS NOT NULL AND (start_date < '2021-12-31' AND next_date > '2020-12-31'))
      OR (next_date IS NULL AND start_date < '2020-12-31')
GROUP BY plan_id)
SELECT 
    plan_id,
    num_customer,
    ROUND(num_customer * 100/(SELECT COUNT(DISTINCT customer_id) FROM subscriptions),1) AS Perc_Customer
FROM Plans_Breakdown
GROUP BY  plan_id, num_customer
ORDER BY  plan_id;
      
/* On December 31, 2020, more people subscribed or upgraded to the pro monthly plan, but fewer people signed up
for the trial plan. Could it be that some new customers signed up for paid plans immediately? If not, Foodie-Fi
needs to scale up its marketing strategies for acquiring new sign-ups during this period as it's a holiday period,
and as an entertainment platform, it's supposed to have more customers testing out the platform.
*/    
      

-- 8. How many customers have upgraded to an annual in 2020?

-- use the count cluase to find no of customers and where cluase to filter 

SELECT 
COUNT(customer_id) AS num_customer
FROM SUBSCRIPTIONS
WHERE plan_id = 3 AND start_date <= '2020-12-31';

-- 195 customers upgraded to an annual plan in 2020


-- 9. How many days on average does it take for a customer to an annual plan from the day they joined Foodie-Fi?

/*
* Assuming join date same as trial start date, fetch data for trial and annual plan separately
* Use DATEDIFF to extract days from the difference between trial and annual start date
* Use AVG to find the average length of days it takes to buy an annual plan.
*/

-- Filter results to customers at trial plan = 0
WITH trial_plan AS (
    SELECT customer_id,
           start_date AS trial_date
    FROM subscriptions
    WHERE plan_id = 0
),

-- Filter results to customers on annual plan = 3
annual_plan AS (
    SELECT customer_id,
           start_date as annual_date
    FROM subscriptions
    WHERE plan_id = 3
)

-- Find the difference between the two dates
SELECT ROUND(AVG(DATEDIFF(annual_date, trial_date)), 0) AS avg_days_to_upgrade
FROM trial_plan tp
JOIN annual_plan ap
ON tp.customer_id = ap.customer_id;

    -- On average, it takes 105 days for customers to upgrade to an annual plan after they join Foodie-Fi

    
-- 10. Can you further breakdown this average value into 30 day periods? (i.e. 0–30 days, 31–60 days etc)

WITH trial_plan AS (
    SELECT customer_id, start_date AS trial_date
    FROM subscriptions
    WHERE plan_id = 0
),
annual_plan AS (
    SELECT customer_id, start_date AS annual_date
    FROM subscriptions
    WHERE plan_id = 3
)

SELECT
    CONCAT(FLOOR(DATEDIFF(ap.annual_date, tp.trial_date) / 30) * 30, '-', FLOOR(DATEDIFF(ap.annual_date, tp.trial_date) / 30) * 30 + 30, ' days') AS period,
    COUNT(*) AS total_customers,
    ROUND(AVG(DATEDIFF(ap.annual_date, tp.trial_date)), 0) AS avg_days_to_upgrade
FROM trial_plan tp
JOIN annual_plan ap ON tp.customer_id = ap.customer_id
WHERE ap.annual_date IS NOT NULL
GROUP BY CONCAT(FLOOR(DATEDIFF(ap.annual_date, tp.trial_date) / 30) * 30, '-', FLOOR(DATEDIFF(ap.annual_date, tp.trial_date) / 30) * 30 + 30, ' days');

/*
Upon further analysis, I discovered the following trends:

* The majority of customers opt to subscribe or upgrade to an annual plan within the first 30 days.
* A smaller percentage of customers make the decision to subscribe or upgrade after 210 days.
* After 270 days, there is almost no customer activity in terms of purchasing a plan.
*/
     
-- 11. How many customers downgraded from a pro monthly to a basic monthly plan in 2020?
 
 /*Steps:
* Use the LEAD() function to get the next plan after their initial plan
* COUNT the number of customers that dowgraded from pro monthly to basic monthly in 2020
*/
          
WITH next_plan AS (
   SELECT *, 
      LEAD(plan_id,1) OVER(PARTITION BY customer_id 
      ORDER BY start_date, plan_id) AS Plan
   FROM subscriptions)
SELECT 
   COUNT(DISTINCT customer_id) AS Num_Downgrade
FROM next_plan np
LEFT JOIN plans p
ON p.plan_id = np.plan_id
WHERE p.plan_name = 'Pro Monthly' AND np.plan = 1 AND start_date <= '2020-12-31';

-- No customer has downgraded from pro monthly to basic monthly in 2020.







