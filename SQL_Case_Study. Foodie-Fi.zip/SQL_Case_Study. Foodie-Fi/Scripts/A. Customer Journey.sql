/*Based off the 3 sample customers provided in the sample from the subscriptions table, write a brief
description about each customer’s onboarding journey.Try to keep it as short as possible - you may also
want to run some sort of join to make your explanations a bit easier!*

### Steps to answering the question:

- The sample customer_id given in the sample subscription table are 1, 2, 11.

- Create a base table with the following columns: customer_id, plan_id, plan_name, start_date.

- Order by Customer_id
*/	
 -- Solution

-- selecting the unique customers based on the sample from the subscriptions table

SELECT s.customer_id,
	   p.plan_id, 
	   p.plan_name, 
	   s.start_date
FROM plans AS p
INNER JOIN subscriptions AS s
ON p.plan_id = s.plan_id
WHERE s.customer_id IN (1,2,11);-- selected 3 unique customers;

-- Output
	
customer_id | plan_id | plan_name | start_date
--|--|--|--|
1	|0	|trial	|2020-08-01
1	|1	|basic monthly	|2020-08-08
2	|0	|trial	|2020-09-20
2	|3	|pro annual	|2020-09-27
11	|0	|trial	|2020-11-19
11	|4	|churn	|2020-11-26

	
-- Brief description on the customers journey based on the results from the above query:

 - Customer 1 starts with a free trial plan on 2020-08-01 and when the trial ends, upgrades to basic monthly plan on 2020-08-08

 - Customer 2 starts with a free trial plan on 2020-09-20 and when the trial ends, upgrades to pro annual plan on 2020-09-27

 - Customer 11 starts with free trial plan on 2020-11-19 and churns at the end of the free trial plan on 2020-11-26

 